/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.ejerciciofeedback5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class EjercicioFeedback5 {

    public static void main(String[] args) {

        try {
            //En primer lugar configuramos el acceso a la base de datos
            String url = "jdbc:mysql://localhost:4306/vehículos_ef5";
            String usuario = "user-dam";
            String pass = "dam-password-1234";
            Scanner teclado = new Scanner(System.in);
            Connection con = DriverManager.getConnection(url, usuario, pass);
            System.out.println("Conexión correcta");
            Statement s = con.createStatement();
            //A continuación, en la base de datos "vehículos_ef5" creamos la tabla "vehículos" 
            //con las características que nos expone el ejercicio
            boolean salida = s.execute("CREATE TABLE IF NOT EXISTS `vehículos_ef5`.`vehículos` "
                    + "(`marca` VARCHAR(30) NOT NULL , "
                    + "`modelo` VARCHAR(30) NOT NULL , `tipo_motor` CHAR NOT NULL , `anio_lanzamiento` VARCHAR (4) NOT NULL)");
            System.out.println("Tabla creada correctamente");
            //Insertamos varios modelos de coches en la tabla

            int n = s.executeUpdate("INSERT INTO `vehículos` (`marca`, `modelo`, `tipo_motor`, `anio_lanzamiento`) "
                    + "VALUES ('Ford', 'Fiesta ST', 'G', '2005')");
            n = s.executeUpdate("INSERT INTO `vehículos` (`marca`, `modelo`, `tipo_motor`, `anio_lanzamiento`) "
                    + "VALUES ('Renault', 'Twingo', 'E', '2023')");
            n = s.executeUpdate("INSERT INTO `vehículos` (`marca`, `modelo`, `tipo_motor`, `anio_lanzamiento`) "
                    + "VALUES ('Citroen', 'Berlingo', 'D', '1999')");
            n = s.executeUpdate("INSERT INTO `vehículos` (`marca`, `modelo`, `tipo_motor`, `anio_lanzamiento`) "
                    + "VALUES ('Renault', 'Megane', 'H', '2018')");
            n = s.executeUpdate("INSERT INTO `vehículos` (`marca`, `modelo`, `tipo_motor`, `anio_lanzamiento`) "
                    + "VALUES ('Ferrari', 'Barato', 'E', '2023')");
            n = s.executeUpdate("INSERT INTO `vehículos` (`marca`, `modelo`, `tipo_motor`, `anio_lanzamiento`) "
                    + "VALUES ('FIAT', '500', 'E', '2023')");
            n = s.executeUpdate("INSERT INTO `vehículos` (`marca`, `modelo`, `tipo_motor`, `anio_lanzamiento`) "
                    + "VALUES ('Smart', 'TV', 'H', '2018')");
            n = s.executeUpdate("INSERT INTO `vehículos` (`marca`, `modelo`, `tipo_motor`, `anio_lanzamiento`) "
                    + "VALUES ('Tesla', 'S', 'G', '2058')");

            System.out.println("Valores introducidos correctamente");

            //Configuramos los PreparedStatement para acceder a los valores que queremos de la base de datos
            String sqlSelect = "SELECT * FROM vehículos WHERE tipo_motor=? and anio_lanzamiento=?";
            PreparedStatement select = con.prepareStatement(sqlSelect);

            Statement insercion = con.createStatement();

            String tipo_motor = JOptionPane.showInputDialog("Dame el tipo de motor"
                    + " *(D-diésel, G-gasolina, E-eléctrico, H-híbrido):");

            String year = JOptionPane.showInputDialog("Dame el año de lanzamiento:");

            select.setString(1, tipo_motor);
            select.setString(2, year);

            ResultSet registros = select.executeQuery();
            System.out.println("Ejecutando consulta");
            //Se prepara para que salgan los resultado por pantalla

            while (registros.next()) {
                System.out.println(registros.getString(1));
                System.out.println(registros.getString(2));
                System.out.println(registros.getString(3));
                System.out.println(registros.getString(4));
                System.out.println(" - ");

            }

        } catch (SQLException e) {
            //Tratamiento de los posibles errores SQL a la hora de ejecutar el programa
            System.out.println("Error SQL");
        }

    }
}
